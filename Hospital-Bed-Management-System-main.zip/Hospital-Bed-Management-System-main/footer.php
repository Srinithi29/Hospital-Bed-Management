<div class="clear"></div>
</div>
</div>
<p id="footer">Hospital Bed Management System &copy; JORIM TECHNOLOGY 2023</p>
</div>
<script src="./jquery-3.6.3.min.js"></script>
<script src="./bootstrap.min.js"></script>
</body>

</html>
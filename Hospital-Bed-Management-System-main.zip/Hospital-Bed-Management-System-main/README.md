Dowload the Zip file and extract it.
Copy the extracted folder.
Install Xampp and start the apache and mysql.
Go to Xampp folder->htdocs-> Paste the folder here.
Type "local host" on any browser URL
Now click on the PhpMyAdmin 
Create a new database it should be named as sql file name(hbms).
Import the sql file(named "hbms" available in the extracted folder) on the database which is created.
Type "localhost/FOLDER NAME"(localhost/Hospital-Bed-Management-master/) on the URL.
